﻿using Top10.DAL.Model;
using Top10.DAL.Repositories.Infrastructure;

namespace Top10.DAL.Repositories
{
    public class QuestionRepository : RepositoryBase<Question>
    {
    }
}