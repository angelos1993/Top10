﻿$(() => {
    $("a[href$='somee.com']").parent().hide();
});