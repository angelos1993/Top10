﻿namespace Top10.DAL.VMs
{
    public class TopUserVm
    {
        public string Username { get; set; }
        public int TotalGrades { get; set; }
    }
}