﻿namespace Top10.DAL.VMs
{
    public class FeedbackVm
    {
        public string Username { get; set; }
        public string Message { get; set; }
    }
}